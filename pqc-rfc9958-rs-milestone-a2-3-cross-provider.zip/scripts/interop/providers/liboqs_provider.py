#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[3]
SRC=pathlib.Path(__file__).with_name("liboqs_bridge.c")
BIN=ROOT/"target"/"interop"/"liboqs_bridge"
def prefix():
 p=os.environ.get("OQS_PREFIX")
 if p:return pathlib.Path(p)
 lib=os.environ.get("OQS_LIBOQS_PATH")
 if lib:return pathlib.Path(lib).resolve().parent.parent
 return pathlib.Path("/opt/homebrew") if pathlib.Path("/opt/homebrew/include/oqs/oqs.h").exists() else pathlib.Path("/usr/local")
def ensure_bridge():
 pre=prefix();BIN.parent.mkdir(parents=True,exist_ok=True)
 if not BIN.exists() or BIN.stat().st_mtime<SRC.stat().st_mtime:
  cc=os.environ.get("CC","cc");cmd=[cc,"-std=c11",str(SRC),"-I",str(pre/"include"),"-L",str(pre/"lib"),f"-Wl,-rpath,{pre/'lib'}","-loqs","-o",str(BIN)]
  p=subprocess.run(cmd,capture_output=True,text=True)
  if p.returncode: raise RuntimeError(p.stderr.strip())
 return BIN
def execute(req):
 op=req["operation"];ps=req["parameter_set"];i=req.get("inputs",{});args=[str(ensure_bridge()),op,ps]
 if op=="kem-encaps":args += [i["public_key"]]
 elif op=="kem-decaps":args += [i["secret_key"],i["ciphertext"]]
 elif op=="dsa-sign":args += [i["secret_key"],i["message"],i.get("context","")]
 elif op=="dsa-verify":args += [i["public_key"],i["message"],i.get("context",""),i["signature"]]
 p=subprocess.run(args,capture_output=True,text=True)
 if p.returncode: raise RuntimeError(p.stderr.strip() or f"bridge exit {p.returncode}")
 out={}
 for line in p.stdout.splitlines():
  k,v=line.split("=",1);out[k]=(v=="true" if k=="valid" else v)
 return out
try:
 req=json.load(sys.stdin)
 if req.get("action")=="capabilities":
  ensure_bridge();outputs={"provider":"liboqs","operations":["kem-keygen","kem-encaps","kem-decaps","dsa-keygen","dsa-sign","dsa-verify"]}
 else: outputs=execute(req)
 print(json.dumps({"ok":True,"outputs":outputs}))
except Exception as e:
 print(json.dumps({"ok":False,"error":str(e)}));sys.exit(1)
