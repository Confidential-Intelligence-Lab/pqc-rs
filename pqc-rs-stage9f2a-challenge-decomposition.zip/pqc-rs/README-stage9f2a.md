# Stage 9F-2A

```bash
unzip -o pqc-rs-stage9f2a-challenge-decomposition.zip
cp -R pqc-rs/. .
rm -rf pqc-rs
./scripts/run-stage9f2a-challenge-decomposition.sh
```
