#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,math,statistics
from collections import defaultdict
from pathlib import Path
def welch_t(a,b):
 d=math.sqrt(statistics.variance(a)/len(a)+statistics.variance(b)/len(b)); return 0.0 if d==0 else (statistics.fmean(a)-statistics.fmean(b))/d
def main():
 p=argparse.ArgumentParser(); p.add_argument("csv",type=Path); args=p.parse_args(); classes=defaultdict(list)
 with args.csv.open(newline="",encoding="utf-8") as s:
  for row in csv.DictReader(s): classes[int(row["class"])].append(float(row["nanoseconds"]))
 labels={0:"first-byte mismatch",1:"middle-byte mismatch",2:"last-byte mismatch",3:"equal"}
 for cid in sorted(classes):
  v=classes[cid]; print(f"class {cid} ({labels[cid]}): n={len(v)} mean={statistics.fmean(v):.2f} ns median={statistics.median(v):.2f} ns")
 comps=((0,1),(0,2),(1,2),(0,3),(2,3)); m=0.0; print("\nWelch t comparisons:")
 for l,r in comps:
  t=welch_t(classes[l],classes[r]); m=max(m,abs(t)); print(f"  {labels[l]} vs {labels[r]}: t={t:.6f}")
 print(f"\nmaximum absolute t: {m:.6f}"); print("investigate |t| >= 4.5")
if __name__=="__main__": main()
