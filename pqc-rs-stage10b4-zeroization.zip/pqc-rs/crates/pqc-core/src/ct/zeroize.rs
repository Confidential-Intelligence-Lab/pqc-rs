//! Explicit zeroization primitives for secret-bearing memory.

use core::{
    ptr,
    sync::atomic::{compiler_fence, Ordering},
};

/// Overwrite a mutable byte slice with zeros using volatile stores.
#[inline(never)]
pub fn zeroize_bytes(value: &mut [u8]) {
    for byte in value {
        unsafe {
            ptr::write_volatile(byte, 0);
        }
    }

    compiler_fence(Ordering::SeqCst);
}

/// Overwrite a mutable `u16` slice with zeros using volatile stores.
#[inline(never)]
pub fn zeroize_u16(value: &mut [u16]) {
    for element in value {
        unsafe {
            ptr::write_volatile(element, 0);
        }
    }

    compiler_fence(Ordering::SeqCst);
}

/// Overwrite a mutable `u32` slice with zeros using volatile stores.
#[inline(never)]
pub fn zeroize_u32(value: &mut [u32]) {
    for element in value {
        unsafe {
            ptr::write_volatile(element, 0);
        }
    }

    compiler_fence(Ordering::SeqCst);
}

/// Overwrite a mutable `u64` slice with zeros using volatile stores.
#[inline(never)]
pub fn zeroize_u64(value: &mut [u64]) {
    for element in value {
        unsafe {
            ptr::write_volatile(element, 0);
        }
    }

    compiler_fence(Ordering::SeqCst);
}
