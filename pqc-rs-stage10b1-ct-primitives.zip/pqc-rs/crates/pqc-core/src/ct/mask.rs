//! Constant-time masks and equality predicates.

macro_rules! define_mask {
    ($name:ident, $integer:ty, $bits:expr, $is_zero:ident, $is_nonzero:ident, $eq:ident) => {
        #[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
        #[repr(transparent)]
        pub struct $name($integer);

        impl $name {
            pub const FALSE: Self = Self(0);
            pub const TRUE: Self = Self(<$integer>::MAX);

            pub const fn from_raw(value: $integer) -> Self {
                debug_assert!(value == 0 || value == <$integer>::MAX);
                Self(value)
            }

            pub const fn raw(self) -> $integer {
                self.0
            }

            pub const fn not(self) -> Self {
                Self(!self.0)
            }

            pub const fn and(self, other: Self) -> Self {
                Self(self.0 & other.0)
            }

            pub const fn or(self, other: Self) -> Self {
                Self(self.0 | other.0)
            }

            pub const fn xor(self, other: Self) -> Self {
                Self(self.0 ^ other.0)
            }
        }

        pub const fn $is_zero(value: $integer) -> $name {
            let nonzero = value | value.wrapping_neg();
            let bit = nonzero >> ($bits - 1);
            $name::from_raw(bit.wrapping_sub(1))
        }

        pub const fn $is_nonzero(value: $integer) -> $name {
            $is_zero(value).not()
        }

        pub const fn $eq(left: $integer, right: $integer) -> $name {
            $is_zero(left ^ right)
        }
    };
}

define_mask!(CtMask8, u8, 8, ct_is_zero_u8, ct_is_nonzero_u8, ct_eq_u8);
define_mask!(CtMask16, u16, 16, ct_is_zero_u16, ct_is_nonzero_u16, ct_eq_u16);
define_mask!(CtMask32, u32, 32, ct_is_zero_u32, ct_is_nonzero_u32, ct_eq_u32);
define_mask!(CtMask64, u64, 64, ct_is_zero_u64, ct_is_nonzero_u64, ct_eq_u64);
