//! Constant-time utility primitives.

mod mask;
mod select;

pub use mask::{
    ct_eq_u8, ct_eq_u16, ct_eq_u32, ct_eq_u64, ct_is_nonzero_u8,
    ct_is_nonzero_u16, ct_is_nonzero_u32, ct_is_nonzero_u64,
    ct_is_zero_u8, ct_is_zero_u16, ct_is_zero_u32, ct_is_zero_u64,
    CtMask8, CtMask16, CtMask32, CtMask64,
};
pub use select::{
    ct_assign_bytes, ct_select_bytes, ct_select_u8, ct_select_u16,
    ct_select_u32, ct_select_u64,
};
