#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="${1:-target/stage9f4c}"
mkdir -p "${OUT_DIR}"

if ! rustup component list --installed | grep -q '^llvm-tools'; then
  rustup component add llvm-tools-preview
fi

if ! command -v cargo-objdump >/dev/null 2>&1; then
  echo "cargo-binutils is required." >&2
  echo "Install with: cargo install cargo-binutils" >&2
  exit 1
fi

RUSTFLAGS="-C target-cpu=native -C debuginfo=2 -C force-frame-pointers=yes" \
cargo build \
  -p pqc-rs-test-harness \
  --bin mldsa-stage9f4c-audit \
  --release

BINARY="target/release/mldsa-stage9f4c-audit"

cargo objdump \
  --bin mldsa-stage9f4c-audit \
  --release \
  -- \
  --demangle \
  --disassemble \
  --no-show-raw-insn \
  > "${OUT_DIR}/audit-binary.objdump.txt"

cargo nm \
  --bin mldsa-stage9f4c-audit \
  --release \
  -- \
  --demangle \
  > "${OUT_DIR}/audit-binary.nm.txt"

rustc --version --verbose > "${OUT_DIR}/rustc-version.txt"
cargo --version > "${OUT_DIR}/cargo-version.txt"
uname -a > "${OUT_DIR}/system.txt"

echo "Recovered optimized machine code under ${OUT_DIR}."
